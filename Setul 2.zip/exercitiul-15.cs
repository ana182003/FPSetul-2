﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercitiul15
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n, x, y;
            bool? crescator = null;
            bool ok = true, switched = false;
            n = int.Parse(Console.ReadLine());
            x = int.Parse(Console.ReadLine());
            for (int i = 1; i < n; i++)
            {
                y = int.Parse(Console.ReadLine());
                if (x < y)
                {
                    if (!crescator.HasValue)
                    {
                        crescator = true;
                    }
                    else if (!crescator.Value && !switched)
                    {
                        switched = true;
                        crescator = true;
                    }
                    else if (!crescator.Value && switched)
                    {
                        ok = false;
                    }
                }
                if (x > y)
                {
                    if (!crescator.HasValue)
                    {
                        crescator = false;
                    }
                    else if (crescator.Value && !switched)
                    {
                        switched = true;
                        crescator = false;
                    }
                    else if (crescator.Value && switched)
                    {
                        ok = false;
                    }
                }
                x = y;
            }
            if (ok && switched == true)
            {
                Console.WriteLine("Secventa este bitonica");
            }
            else
            {
                Console.WriteLine("Secventa nu este bitonica");
            }
        }
    }
}
