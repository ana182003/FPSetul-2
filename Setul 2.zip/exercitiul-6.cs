﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercitiul6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            bool a = true;
            int x1 = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                int x2 = int.Parse(Console.ReadLine());
                if (x1 > x2)
                {
                    a = false;
                }
                x1 = x2;
            }
            if (a)
            {
                Console.WriteLine($"Șirul este în ordine crescătoare.");
            }
            else
                Console.WriteLine($"Șirul nu este în ordine crescătoare.");
        }
    }
}