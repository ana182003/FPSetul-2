﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercitiul10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int max = 1;
            int nr = 1;
            int x1 = int.Parse(Console.ReadLine());
            for (int i = 1; i < n; i++)
            {
                int x2 = int.Parse(Console.ReadLine());
                if (x1 == x2)
                {
                    nr++;
                }
                else
                    nr = 1;
                if (nr > max)
                {
                    max = nr;
                }
                x1 = x2;
            }
            Console.WriteLine($"Numarul maxim de numere conscutive din secventa este {max}");
        }
    }
}