﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercitiul12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int nr = 0;
            int x1 = int.Parse(Console.ReadLine());
            if (x1 != 0)
                nr++;
            for (int i = 1; i < n; i++)
            {
                int x2 = int.Parse(Console.ReadLine());
                if (x2 != 0 && x1 == 0)
                    nr++;
                x1 = x2;
            }
            Console.WriteLine(nr);
        }
    }
}