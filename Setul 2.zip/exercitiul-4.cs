﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercitiul4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int a = int.Parse(Console.ReadLine());
            int poz = -1;
            for (int i = 0; i < n; i++)
            {
                int x = int.Parse(Console.ReadLine());
                if (x == a)
                {
                    poz = i;
                }
            }
            if (poz == -1)
            {
                Console.WriteLine($" {poz} ");
            }
            else

                Console.WriteLine($"Pozitia lui {a} este {poz}");
        }
    }
}