﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercitiul9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            bool a1 = true;
            bool a2 = true;
            int x1 = int.Parse(Console.ReadLine());
            for (int i = 1; i < n; i++)
            {
                int x2 = int.Parse(Console.ReadLine());
                if (x1 > x2)
                {
                    a1 = false;
                }
                if (x1 < x2)
                {
                    a2 = false;
                }
                x1 = x2;
            }
            if (a1 || a2)
            {
                Console.WriteLine($"Sirul este monoton");
            }
            else
                Console.WriteLine($"Sirul nu este monoton");
        }
    }
}