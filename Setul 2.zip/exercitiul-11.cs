﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercitiul11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int s = 0;
            for (int i = 0; i < n; i++)
            {
                int x = int.Parse(Console.ReadLine());
                int xinv = 0;
                while (x > 0)
                {
                    xinv = xinv * 10 + x % 10;
                    x /= 10;
                }
                s += xinv;
            }
            Console.WriteLine(s);
        }
    }
}