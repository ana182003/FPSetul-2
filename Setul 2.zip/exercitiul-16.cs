﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercitiul16
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int x1 = int.Parse(Console.ReadLine());
            bool? crescator = null;
            bool ok = true, switched = false;
            int prim = x1;
            int bec1 = 0;
            int bec2 = 0;
            for (int i = 1; i < n; i++)
            {
                int x2 = int.Parse(Console.ReadLine());
                if (x1 > x2)
                {
                    bec1++;
                }
                if (x1 < x2)
                {
                    bec2++;
                }
                x1 = x2;
                if (x1 < x2)
                {
                    if (!crescator.HasValue)
                    {
                        crescator = true;
                    }
                    else if (!crescator.Value && !switched)
                    {
                        switched = true;
                        crescator = true;
                    }
                    else if (!crescator.Value && switched)
                    {
                        ok = false;
                    }
                }
                if (x1 > x2)
                {
                    if (!crescator.HasValue)
                    {
                        crescator = false;
                    }
                    else if (crescator.Value && !switched)
                    {
                        switched = true;
                        crescator = false;
                    }
                    else if (crescator.Value && switched)
                    {
                        ok = false;
                    }
                }
                x1 = x2;
            }
            if ((bec1 == 1 && prim > x1) ^ (bec2 == 1 && prim < x1) && ok && switched == true)
            {
                Console.WriteLine($"Secventa este bitonica rotita");
            }
            else
                Console.WriteLine($"Secventa nu este bitonica rotita");
        }
    }
}