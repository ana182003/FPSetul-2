﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercitiul8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int f1 = 0;
            int f2 = 1;
            int fn = 0;
            for (int i = 2; i <= n; i++)
            {
                fn = f2 + f1;
                f1 = f2;
                f2 = fn;
            }
            Console.WriteLine($"{fn}");
        }
    }
}
