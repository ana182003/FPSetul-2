﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercitiul3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ulong n = ulong.Parse(Console.ReadLine());
            ulong s = 0;
            ulong p = 1;
            for (ulong i = 1; i <= n; i++)
            {
                s += i;
                p *= i;
            }
            Console.WriteLine("Suma este egală cu " + s + " iar produsul este egal cu " + p);
        }
    }
}