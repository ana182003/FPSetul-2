﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercitiul17
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] t = Console.ReadLine().Split(' ');
            int zero = 0;
            int unu = 0;
            int a = 0;
            int incuibare = 0;
            int incuibaremax = 0;
            for (int i = 0; i < t.Length; i++)
            {
                a = int.Parse(t[i]);
                if (a == 0)
                {
                    zero++;
                    incuibare++;
                }
                if (a == 1)
                {
                    unu++;
                    incuibare = 0;
                }
                if (incuibare > incuibaremax)
                    incuibaremax = incuibare;
            }
            if (t[0] == "1" || t[t.Length - 1] == "0")
                Console.WriteLine($"Secventa este incorecta");
            else if (unu == zero && a != 0)
                Console.WriteLine($"Secventa este corecta si incuibarea maxima este {incuibaremax}");
            else
                Console.WriteLine($"Secventa este incorecta");
        }
    }
}