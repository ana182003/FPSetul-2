﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercitiul13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int x1 = int.Parse(Console.ReadLine());
            int prim = x1;
            int bec = 0;
            for (int i = 1; i < n; i++)
            {
                int x2 = int.Parse(Console.ReadLine());
                if (x1 > x2)
                {
                    bec++;
                }
                x1 = x2;
            }
            if (bec == 1 && prim > x1)
            {
                Console.WriteLine($"Secventa este crescatoare rotita");
            }
            else
                Console.WriteLine($"Secventa nu este crescatoare rotita");
        }
    }
}

